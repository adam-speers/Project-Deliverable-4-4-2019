﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txtTeam11Username = New System.Windows.Forms.TextBox()
        Me.txtTeam11Password = New System.Windows.Forms.TextBox()
        Me.lblTeam11Username = New System.Windows.Forms.Label()
        Me.lblTeam11Password = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtTeam11Username
        '
        Me.txtTeam11Username.Location = New System.Drawing.Point(160, 188)
        Me.txtTeam11Username.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtTeam11Username.Name = "txtTeam11Username"
        Me.txtTeam11Username.Size = New System.Drawing.Size(264, 31)
        Me.txtTeam11Username.TabIndex = 0
        '
        'txtTeam11Password
        '
        Me.txtTeam11Password.Location = New System.Drawing.Point(171, 331)
        Me.txtTeam11Password.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtTeam11Password.Name = "txtTeam11Password"
        Me.txtTeam11Password.Size = New System.Drawing.Size(264, 31)
        Me.txtTeam11Password.TabIndex = 1
        '
        'lblTeam11Username
        '
        Me.lblTeam11Username.AutoSize = True
        Me.lblTeam11Username.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTeam11Username.Location = New System.Drawing.Point(165, 126)
        Me.lblTeam11Username.Name = "lblTeam11Username"
        Me.lblTeam11Username.Size = New System.Drawing.Size(121, 26)
        Me.lblTeam11Username.TabIndex = 2
        Me.lblTeam11Username.Text = "Username"
        '
        'lblTeam11Password
        '
        Me.lblTeam11Password.AutoSize = True
        Me.lblTeam11Password.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTeam11Password.Location = New System.Drawing.Point(165, 284)
        Me.lblTeam11Password.Name = "lblTeam11Password"
        Me.lblTeam11Password.Size = New System.Drawing.Size(116, 26)
        Me.lblTeam11Password.TabIndex = 3
        Me.lblTeam11Password.Text = "Password"
        '
        'PictureBox1
        '
        Me.PictureBox1.ErrorImage = Global.TP_1_Team_11.My.Resources.Resources.image
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = Global.TP_1_Team_11.My.Resources.Resources.image
        Me.PictureBox1.Location = New System.Drawing.Point(851, 38)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(828, 512)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(160, 494)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(265, 56)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Enter"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1739, 621)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTeam11Password)
        Me.Controls.Add(Me.lblTeam11Username)
        Me.Controls.Add(Me.txtTeam11Password)
        Me.Controls.Add(Me.txtTeam11Username)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.Text = "Welcome"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtTeam11Username As TextBox
    Friend WithEvents txtTeam11Password As TextBox
    Friend WithEvents lblTeam11Username As Label
    Friend WithEvents lblTeam11Password As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
End Class
