﻿Public Class ObjectCreator
    Public Sub CreateObjectsAndLists()

        Dim myConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\ASET\Desktop\ProjectDatabase.mdb"
        Dim mySQL As String
        Dim tablename As String
        Dim myDataSet As New DataSet
        Dim myDBMS As New DBMS

        tablename = "CarTable"
        mySQL = "SELECT * FROM " & tablename
        myDBMS.RunSQL(tablename, mySQL, myDataSet, myConnectionString)

        For rowNumber As Integer = 0 To myDataSet.Tables(tablename).Rows.Count - 1
            Dim myCar As New CarTable
            myCar.ID = myDataSet.Tables(tablename).Rows(rowNumber)("ID")
            myCar.CarName = myDataSet.Tables(tablename).Rows(rowNumber)("Location")
            myCar.Cost = myDataSet.Tables(tablename).Rows(rowNumber)("Cost")
            myCar.MPG = myDataSet.Tables(tablename).Rows(rowNumber)("MPG")
            myCar.Comfort = myDataSet.Tables(tablename).Rows(rowNumber)("Comfort")
            myCar.Utility = myDataSet.Tables(tablename).Rows(rowNumber)("Utility")
            myCar.Interior = myDataSet.Tables(tablename).Rows(rowNumber)("Interior")

            CarTable.CarTableList.Add(myCar)
        Next
    End Sub


End Class
